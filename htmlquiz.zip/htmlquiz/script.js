const startButton = document.getElementById('start-btn');
const nextButton = document.getElementById('next-btn');
const questionContainerElement = document.getElementById('question-container');
const questionElement = document.getElementById('question');
const answerButtonsElement = document.getElementById('answer-buttons');
let shuffledQuestions, currentQuestionIndex;
let quizScore = 0;

startButton.addEventListener("click", startGame);

nextButton.addEventListener("click", () => {
    currentQuestionIndex++;
    setNextQuestion();
});

function startGame() {
    startButton.classList.add("hide");
    shuffledQuestions = questions.sort(() => Math.random() - 0.5);
    currentQuestionIndex = 0;
    questionContainerElement.classList.remove("hide");
    setNextQuestion();
    quizScore = 0;
    document.getElementById('right-answers').innerHTML = quizScore; // Reset score display

    // Update total questions count
    document.getElementById('total-questions').textContent = questions.length;
}

function setNextQuestion() {
    resetState();
    showQuestion(shuffledQuestions[currentQuestionIndex]);
}

function showQuestion(question) {
    questionElement.innerText = question.question;
    question.answers.forEach((answer) => {
        const button = document.createElement("button");
        button.innerText = answer.text;
        button.classList.add("btn");
        if (answer.correct === "true") {
            button.dataset.correct = answer.correct;
        }
        button.addEventListener("click", selectAnswer);
        answerButtonsElement.appendChild(button);
    });
}

function resetState() {
    clearStatusClass(document.body);
    nextButton.classList.add("hide");
    while (answerButtonsElement.firstChild) {
        answerButtonsElement.removeChild(answerButtonsElement.firstChild);
    }
}

function selectAnswer(e) {
    const selectedButton = e.target;
    const correct = selectedButton.dataset.correct;

    // Set color of selected button
    setStatusClass(selectedButton, correct);

    // Disable further clicks on buttons
    Array.from(answerButtonsElement.children).forEach(button => {
        button.disabled = true;
    });

    // Check if answer is correct and update score
    if (correct === "true") {
        quizScore++;
        document.getElementById('right-answers').innerHTML = quizScore; // Update score display
    }

    // Show next button or restart button
    if (shuffledQuestions.length > currentQuestionIndex + 1) {
        nextButton.classList.remove("hide");
    } else {
        startButton.innerText = "Restart";
        startButton.classList.remove("hide");
    }

    // Update the score display
    document.getElementById('right-answers').textContent = quizScore;
}

function setStatusClass(element, correct) {
    clearStatusClass(element);
    if (correct === "true") {
        element.classList.add("correct");
    } else {
        element.classList.add("wrong");
    }
}

function clearStatusClass(element) {
    element.classList.remove("correct");
    element.classList.remove("wrong");
}

const questions = [
    {
        question: 'Which one of these is a JavaScript framework?',
        answers: [
            { text: 'Python', correct: "false" },
            { text: 'Django', correct: "false" },
            { text: 'React', correct: "true" },
            { text: 'Eclipse', correct: "false" },
        ],
    },
    {
        question: 'Who is the President of the USA?',
        answers: [
            { text: 'Biden', correct: "true" },
            { text: 'Trump', correct: "false" },
        ],
    },
    {
        question: 'What is 4 * 3?',
        answers: [
            { text: '6', correct: "false" },
            { text: '12', correct: "true" },
        ],
    },
];
